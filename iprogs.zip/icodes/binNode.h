// struct used by bipartite cover

#ifndef binNode_
#define binNode_

struct binNode
{
   int left, right;  // pointers to left and right nodes
};

#endif
